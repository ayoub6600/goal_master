import 'package:flutter/material.dart';
import 'package:goal_master/features/profile/presentation/view/widgets/change_password_body.dart';

class ChangePasswordView extends StatelessWidget {
  const ChangePasswordView({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangePasswordBody();
  }
}
