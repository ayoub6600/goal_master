import 'package:flutter/material.dart';
import 'package:goal_master/features/profile/presentation/view/widgets/update_profile_body.dart';

class UpdateProfileView extends StatelessWidget {
  const UpdateProfileView({super.key});

  @override
  Widget build(BuildContext context) {
    return UpdateProfileBody();
  }
}
