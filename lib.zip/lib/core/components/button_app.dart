import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:goal_master/core/styles/app_text_styles.dart';

class ButtonApp extends StatelessWidget {
  const ButtonApp(
      {super.key,
      required this.text,
      this.textColor,
      this.backGround,
      this.onTap});
  final String text;
  final Color? backGround;
  final Color? textColor;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        padding: EdgeInsets.all(10.h),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFF56ab2f), Color.fromARGB(255, 62, 84, 36)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(12.r),
        ),
        child: Center(
          child: Text(
            text,
            style: AppTextStyles.font16Bold.copyWith(
              color: textColor ?? Colors.white,
            ),
          ),
        ),
      ),
    );
  }
}
