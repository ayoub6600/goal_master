class RoutesKeys {
  static const kSplashView = '/kSplashView';
  static const kOnboarding = '/kOnboarding';
  static const kLogin = '/kLogin';
  static const kRegister = '/kRegister';
  static const kForgotPassword = '/kForgotPassword';
  static const kOtp = '/kOtp';
  static const kNewPassword = '/kNewPassword';
  static const kProfile = '/kProfile';
  static const kChangePassword = '/kChangePassword';
  static const kContact = '/kContact';
  static const kUpdateProfile = '/kUpdateProfile';
  static const kBooking = '/kBooking';
  static const kHome = '/kHome';
  static const kBookingDetails = '/kBookingDetails';
  static const kNotification = '/kNotification';
  static const kBookingItemsDetails = '/kBookingItemsDetails';
  static const kCard = '/kCard';
  static const kFilter = '/kFilter';
  static const kShowAllResulatFiltter = "/ShowAllResulatFiltter";
  static const kAddNewBooking = "/kAddNewBooking";
}
